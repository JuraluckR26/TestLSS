require('dotenv').config()
const db = require('./config/database')
const express = require('express') 
const jwt = require('jsonwebtoken')
const auth = require('./middleware/auth')
const fs = require('fs');
const forge = require('node-forge');
const pemJwk = require('pem-jwk');
const pem = require('pem');
const crypto = require('crypto');
const { exec } = require('child_process');

const cors = require('cors');

const app = express()

app.use(express.json())
app.use(cors());

app.listen(3002, () => {
    console.log('Server is running on port 3002');
});

const verify = (token) => {
    jwt.verify(token, process.env.TOKEN_KEY, (err, decoded) => {
        return false
    })
    return true
}

app.post("/login", async (req, res) => {
    try{
        const {username, password} = req.body
        db.query('SELECT * FROM personal WHERE username = ? AND password = ?', [username, password], (error, results, fields) => {
            if (error) {
                console.error('query error:', error)
                return
            }
            if (results.length > 0) {
                const token = jwt.sign(
                    {user: username},
                    process.env.TOKEN_KEY,
                    {
                        expiresIn: "1h"
                    }
                )
                const returnValue = {
                    username: username,
                    token: token
                }
                res.status(200).json(returnValue)
            }
            else {
                res.status(400).json("invalid")
            }
        })

    } catch(error) {
        console.log(error)
    }
})

app.post("/signUp", async (req, res) => {
    const {username, password, email} = req.body
    const sql = "INSERT INTO personal (username, password, email) VALUES (?, ?, ?)";
    db.query(sql, [username, password, email], (error, results, fields) => {
        if (error) {
            if(error.sqlState == '23000'){
                res.status(409).json('Username is duplicate!!')
            } else {
                console.error('Error inserting data:', error)
            }
            return
        }
        else {
            res.status(200).json('Created new employees successfully')
        }
    })
})

app.get("/showAll", (req, res) => {
    const {row, page} = req.body
    const authHeader = req.get('Authorization');

    const resVerify = verify(authHeader)
    if(resVerify){
        db.query(`SELECT * FROM employees LEFT JOIN position ON employees.positionId = position.positionId; `, [row, (page-1)*10], (error, results, fields) => {
            if (error) {
                console.error('query error:', error)
                return
            }
            if (results.length > 0) {
                res.status(200).json(results)
            }
            else {
                res.status(400).json("invalid")
            }
        })
    } else {
        res.status(401).json("not authorize")
    }
})

app.get("/getPosition", (req, res) => {
    const {row, page} = req.body
    db.query(`SELECT * FROM position; `, [], (error, results, fields) => {
        if (error) {
            console.error('query error:', error)
            return
        }
        if (results.length > 0) {
            res.status(200).json(results)
        }
        else {
            res.status(400).json("invalid")
        }
    })
})

app.post("/create", async (req, res) => {
    const {firstname, lastname, age, positionId} = req.body
    console.log(req.body)
    const authHeader = req.get('Authorization');
    console.log(authHeader)

    const resVerify = verify(authHeader)
    if(resVerify){
        const sql = "INSERT INTO employees (firstname, lastname, age, positionId) VALUES (?, ?, ?, ?)";
        db.query(sql, [firstname, lastname, age, positionId], (error, results, fields) => {
            console.log("results", results)
            console.log("fields", fields)
            if (error) {
                console.error('Error inserting data:', error)
                return
            }
            else {
                res.status(200).json(results)
            }
        })
    } else {
        res.status(401).json("not authorize")
    }
    
})

app.post("/edit", async (req, res) => {
    const {firstname, lastname, age, positionId, personId} = req.body
    const authHeader = req.get('Authorization');

    const resVerify = verify(authHeader)
    if(resVerify){
        const sql = "UPDATE employees SET firstname = ?, lastname = ?, age = ?, positionId = ? WHERE personId = ?";
        db.query(sql, [firstname, lastname, age, positionId, personId], (error, results, fields) => {
            if (error) {
                console.error('Error inserting data:', error)
                return
            }
            else {
                res.status(200).json('Data Update successfully')
            }
        })
    } else {
        res.status(401).json("not authorize")
    }
})

app.post("/delete", async (req, res) => {
    const {personId} = req.body
    const authHeader = req.get('Authorization');

    const resVerify = verify(authHeader)
    if(resVerify){
        const sql = "DELETE FROM employees WHERE personId = ?";
        db.query(sql, [personId], (error, results, fields) => {
            if (error) {
                console.error('Error delate data:', error)
                return
            }
            else {
                res.status(200).json('Delate Data successfully')
            }
        })
    } else {
        res.status(401).json("not authorize")
    }
    // res.status(200).send('hello')
})

app.post("/search", async (req, res) => {
    const {search, row, page} = req.body
    db.query(`SELECT * FROM provice WHERE ? in (AD_LEVEL,TA_ID,TAMBON_T,TAMBON_E,AM_ID,AMPHOE_T,AMPHOE_E,CH_ID,CHANGWAT_T,CHANGWAT_E,LAT,LONGTI) LIMIT ? OFFSET ? `, [search, row, (page-1)*10], (error, results, fields) => {
        if (error) {
            console.error('query error:', error)
            return
        }
        if (results.length > 0) {
            res.status(200).json(results)
        }
        else {
            res.status(400).json("invalid")
        }
    })
})



module.exports = app